<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "smis";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle file upload
function uploadFile($file) {
    if (!isset($file) || $file['error'] != UPLOAD_ERR_OK) {
        return null;
    }

    $target_dir = "uploads/";
    $target_file = $target_dir . basename($file["name"]);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Check if image file is an actual image or fake image
    $check = getimagesize($file["tmp_name"]);
    if ($check === false) {
        echo "<div class='alert error'>File is not an image.</div>";
        $uploadOk = 0;
    }

    // Check file size (5MB maximum)
    if ($file["size"] > 5000000) {
        echo "<div class='alert error'>Sorry, your file is too large.</div>";
        $uploadOk = 0;
    }

    // Allow certain file formats
    if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif") {
        echo "<div class='alert error'>Sorry, only JPG, JPEG, PNG & GIF files are allowed.</div>";
        $uploadOk = 0;
    }

    // Check if $uploadOk is set to 0 by an error
    if ($uploadOk == 0) {
        return null;
    } else {
        if (move_uploaded_file($file["tmp_name"], $target_file)) {
            return $target_file;
        } else {
            echo "<div class='alert error'>Sorry, there was an error uploading your file.</div>";
            return null;
        }
    }
}

// Insert data
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit'])) {
    $firtsname = $_POST['firtsname'];
    $lastname = $_POST['lastname'];
    $fname = $_POST['fname'];
    $identity_no = $_POST['identity_no'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $address = $_POST['address'];
    $dob = $_POST['dob'];
    $gender = $_POST['gender'];
    $education = $_POST['education'];
    $salary = $_POST['salary'];
    $shiptime = $_POST['shiptime'];

    // Handle file upload
    $photo = isset($_FILES["photo"]) ? uploadFile($_FILES["photo"]) : null;

    if ($photo !== null) {
        // Check if identity_no already exists
        $sql = "SELECT * FROM employee WHERE identity_no = $identity_no";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            echo "<div class='alert error'>A record with this Identity No already exists.</div>";
        } else {
            // Insert new record
            $sql = "INSERT INTO employee (firtsname, lastname, fname, identity_no, phone, email, address, dob, gender, photo, education, salary, shiptime) 
                    VALUES ('$firtsname', '$lastname', '$fname', $identity_no, '$phone', '$email', '$address', $dob, '$gender', '$photo', '$education', $salary, '$shiptime')";

            if ($conn->query($sql) === TRUE) {
                echo "<div class='alert success'>New record created successfully</div>";
            } else {
                echo "<div class='alert error'>Error: " . $sql . "<br>" . $conn->error . "</div>";
            }
        }
    }
}

// Delete data
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    // First, get the photo path to delete the file from the server
    $sql = "SELECT photo FROM employee WHERE employee_id=$id";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (file_exists($row['photo'])) {
            unlink($row['photo']);
        }
    }
    // Now, delete the record from the database
    $sql = "DELETE FROM employee WHERE employee_id=$id";
    if ($conn->query($sql) === TRUE) {
        echo "<div class='alert success'>Record deleted successfully</div>";
    } else {
        echo "<div class='alert error'>Error deleting record: " . $conn->error . "</div>";
    }
}

// Search and display data
$search = "";
if (isset($_GET['search'])) {
    $search = $_GET['search'];
}

$sql = "SELECT * FROM employee WHERE firtsname LIKE '%$search%' OR lastname LIKE '%$search%' OR email LIKE '%$search%' OR phone LIKE '%$search%'";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee Records </title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f4f4f4;
        }
        h2 {
            color: #333;
        }
        .form-container, .search-box {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }
        .form-container input, .search-box input {
            width: calc(100% - 22px);
            padding: 10px;
            margin: 5px 0;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        .form-container button, .search-box button {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 10px;
            border-radius: 4px;
            cursor: pointer;
        }
        .form-container button:hover, .search-box button:hover {
            background-color: #0056b3;
        }
        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 4px;
            color: #fff;
        }
        .alert.success {
            background-color: #28a745;
        }
        .alert.error {
            background-color: #dc3545;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: #fff;
        }
        table th, table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        table th {
            background-color: #343a40;
            color: #fff;
        }
        table tr:hover {
            background-color: #f1f1f1;
        }
        .delete-button {
            color: #dc3545;
            text-decoration: none;
        }
        .delete-button:hover {
            text-decoration: underline;
        }
        img {
            max-width: 100px;
            height: auto;
        }
    </style>
</head>
<body>
    <h2>Insert Employee Record </h2>
    <div class="form-container">
        <form action="employee.php" method="post" enctype="multipart/form-data">
            First Name: <input type="text" name="firtsname" required><br>
            Last Name: <input type="text" name="lastname" required><br>
            Father's Name: <input type="text" name="fname" required><br>
            Identity No: <input type="number" name="identity_no" required><br>
            Phone: <input type="text" name="phone" required><br>
            Email: <input type="text" name="email" required><br>
            Address: <input type="text" name="address" required><br>
            Date of Birth: <input type="number" name="dob" required><br>
            Gender: <input type="text" name="gender" required><br>
            Photo: <input type="file" name="photo" accept="image/*"><br>
            Education: <input type="text" name="education" required><br>
            Salary: <input type="number" name="salary" required><br>
            Shift Time: <input type="text" name="shiptime" required><br>
            <button type="submit" style="display: block; width: 100px; margin: 0 auto; text-align: center; color: #000; background-color: #f0f0f0; border: none; padding: 10px; border-radius: 5px;">Submit</button>

        </form>
    </div>

    <div class="search-box">
        <form action="employee.php" method="get">
            <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>" placeholder="Search by First Name, Last Name, Email, or Phone">
            <button type="submit">Search</button>
        </form>
    </div>

    <h2>Employee Records</h2>
    <table>
        <thead>
            <tr>
                <!-- <th>ID</th> -->
                <th>First Name</th>
                <th>Last Name</th>
                <th>Father's Name</th>
                <th>Identity No</th>
                <th>Phone</th>
                <th>Email</th>
                <th>Address</th>
                <th>Date of Birth</th>
                <th>Gender</th>
                <th>Photo</th>
                <th>Education</th>
                <th>Salary</th>
                <th>Shift Time</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>
                       
                        <td>{$row['firtsname']}</td>
                        <td>{$row['lastname']}</td>
                        <td>{$row['fname']}</td>
                        <td>{$row['identity_no']}</td>
                        <td>{$row['phone']}</td>
                        <td>{$row['email']}</td>
                        <td>{$row['address']}</td>
                        <td>{$row['dob']}</td>
                        <td>{$row['gender']}</td>
                        <td><img src='{$row['photo']}' alt='Photo'></td>
                        <td>{$row['education']}</td>
                        <td>{$row['salary']}</td>
                        <td>{$row['shiptime']}</td>
                        <td><a href='employee.php?delete={$row['employee_id']}' class='delete-button' onclick=\"return confirm('Are you sure you want to delete this record?');\">Delete</a></td>
                    </tr>";
                }
            } else {
                echo "<tr><td colspan='14'>No records found</td></tr>";
            }
            ?>
        </tbody>
    </table>
</body>
</html>

<?php
$conn->close();
?>
