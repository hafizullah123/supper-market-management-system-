<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "smis";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission for report generation
$start_date = isset($_POST['start_date']) ? $_POST['start_date'] : '';
$end_date = isset($_POST['end_date']) ? $_POST['end_date'] : '';

if ($start_date && $end_date) {
    // Debugging: Check if dates are received
    echo "<p>Start Date: " . htmlspecialchars($start_date) . "</p>";
    echo "<p>End Date: " . htmlspecialchars($end_date) . "</p>";
    
    // Prepare the SQL statement
    $stmt_report = $conn->prepare("SELECT sales_date, SUM(totalprice) AS total_price, AVG(unitprice) AS unit_price, category
    FROM sales
    WHERE sales_date BETWEEN ? AND ?
    GROUP BY sales_date, category
    HAVING COUNT(*) > 1");
    
    if (!$stmt_report) {
        die("Prepare failed: " . $conn->error);
    }

    $stmt_report->bind_param("ss", $start_date, $end_date);
    $stmt_report->execute();
    $result_report = $stmt_report->get_result();
    
    if (!$result_report) {
        die("Query failed: " . $conn->error);
    }
} else {
    $result_report = null;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sales Report</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        .container {
            max-width: 900px;
        }
        .form-container, .report-container {
            margin-bottom: 30px;
        }
        .btn-submit {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 4px;
            cursor: pointer;
        }
        .btn-submit:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <!-- Report Form -->
        <div class="form-container">
            <h2 class="text-center">Generate Sales Report</h2>
            <form method="POST" action="">
                <div class="form-group">
                    <label for="start_date">Start Date</label>
                    <input type="date" class="form-control" id="start_date" name="start_date" required>
                </div>
                <div class="form-group">
                    <label for="end_date">End Date</label>
                    <input type="date" class="form-control" id="end_date" name="end_date" required>
                </div>
                <button type="submit" class="btn-submit">Generate Report</button>
            </form>
        </div>

        <!-- Report Table -->
        <div class="report-container">
            <h2 class="text-center">Sales Report</h2>
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>Sales Date</th>
                        <th>Total Price</th>
                        <th>Unit Price</th>
                        <th>Category</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($result_report && $result_report->num_rows > 0): ?>
                        <?php while($row = $result_report->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row["sales_date"]); ?></td>
                                <td><?php echo htmlspecialchars($row["total_price"]); ?></td>
                                <td><?php echo htmlspecialchars($row["unit_price"]); ?></td>
                                <td><?php echo htmlspecialchars($row["category"]); ?></td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="4" class="text-center">No records found</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>

<?php
// Close connection
$conn->close();
?>
