<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f0f0f0;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }
        #header {
            background-color: #343a40;
            color: white;
            padding: 15px 20px;
            text-align: center;
            position: fixed;
            top: 0;
            width: 100%;
            z-index: 1000;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        #header h1 {
            margin: 0;
            font-size: 2.5em;
        }
        #sidebar {
            margin-top: 80px;
            background-color: #343a40; /* Match navbar color */
            color: white; /* Text color white */
            padding: 20px;
            border-right: 1px solid #dee2e6;
            height: calc(100vh - 80px);
            position: fixed;
            top: 0;
            left: 0;
            width: 220px;
            overflow-y: auto;
        }
        #sidebar h1 {
            font-size: 1.5em;
            margin-bottom: 20px;
            color: white; /* Sidebar header text color white */
        }
        #sidebar ol {
            padding-left: 0;
            list-style: none;
        }
        #sidebar ol li {
            margin-bottom: 10px;
        }
        #sidebar ol li a {
            display: block;
            padding: 10px;
            color: white; /* Link text color white */
            text-decoration: none;
            font-weight: bold;
            border-radius: 5px;
            transition: background-color 0.3s ease, color 0.3s ease;
        }
        #sidebar ol li a:hover {
            background-color: #495057; /* Lighter shade for hover effect */
            color: #ffffff;
        }
        .content-container {
            margin-left: 240px;
            margin-top: 100px;
            padding: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: calc(100vh - 160px); /* Adjusted for header and footer */
        }
        iframe {
            border: none;
            width: 100%; /* Full width for iframe */
            height: 80vh; /* Set height to 80% of the viewport */
            max-width: 1200px; /* Max width for large screens */
            max-height: 600px; /* Max height for large screens */
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); /* Optional: Add shadow for better visual */
        }
        #footer {
            background-color: #343a40;
            color: white;
            padding: 15px 20px;
            text-align: center;
            width: 100%;
        }
        #footer .email {
            color: #28a745;
        }
        @media (max-width: 768px) {
            #sidebar {
                width: 100%;
                position: static;
                height: auto;
                border-right: none;
                margin-top: 10px;
            }
            .content-container {
                margin-left: 0;
                margin-top: 10px;
                min-height: auto; /* Adjusted height for smaller screens */
            }
            iframe {
                height: 60vh; /* Adjusted height for smaller screens */
                max-height: 300px; /* Adjust max height for smaller screens */
            }
        }
    </style>
</head>
<body>

    <div id="header">
        <h1>Sales Management Information System</h1>
    </div>

    <div id="sidebar">
        <h1>Forms</h1>
        <ol>
            <li><a href="supplier.php" target="content-frame">Supplier</a></li>
            <li><a href="buy.php" target="content-frame">Buy</a></li>
            <li><a href="employee.php" target="content-frame">Employee Form</a></li>
            <li><a href="product.php" target="content-frame">Product</a></li>
            <li><a href="sales.php" target="content-frame">Sales</a></li>
            <li><a href="expense.php" target="content-frame">Expense</a></li>
            <li><a href="select_order.php" target="content-frame">Orders</a></li>
            <li><a href="select_contact.php" target="content-frame">Contact</a></li>
            <li><a href="report_sales.php" target="content-frame">Report</a></li>
            <li><a href="logout.php" target="content-frame">Logout</a></li>
        </ol>
    </div>

    <div class="content-container">
        <iframe name="content-frame" src="ss.jpg"></iframe>
    </div>

    <!-- <div id="footer">
        <b>Phone: 0776767760</b><br>
        <b>Email: <span class="email">hedaytullah.nezami@gmail.com</span></b>
    </div> -->

    <!-- Bootstrap JS (Optional) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
