<html>
<head>
<title> ABC_SSMI</title>
<script type = "text/javascript" src = "js/bootstrap.min.js"></script>
<script type = "text/javascript" src = "js/jquery.min.js"></script>
<script type ="text/javascript " src = "js/script.js"></script>

<link rel = "stylesheet" type ="text/css" href = "css/bootstrap.min.css">
<link rel ="stylesheet " type = "text/css" href = "css/bootstrap-theme.min.css">
<link rel = "stylesheet" type = "text/css" href = "css/style.css">
</head>
<body>
<h1> Welcome to ABC_SSMI </h1>

</body>

</htm