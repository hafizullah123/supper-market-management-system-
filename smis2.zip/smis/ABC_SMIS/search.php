<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "smis";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$query = isset($_POST['query']) ? $conn->real_escape_string($_POST['query']) : '';

// SQL Query to select data from product table based on the search query
$sql = "SELECT * FROM product WHERE category LIKE '%$query%' OR product_name LIKE '%$query%'";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<thead>
            <tr>
                <th>Category</th>
                <th>Product Name</th>
                <th>Quantity</th>
                <th>Unit Price</th>
                <th>Total Price</th>
                <th>Quality</th>
                <th>Company</th>
                <th>Product Date</th>
                <th>Expire Date</th>
                <th>Guaranty</th>
                <th>Image</th>
            </tr>
          </thead>
          <tbody>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>{$row['category']}</td>
                <td>{$row['product_name']}</td>
                <td>{$row['quantity']}</td>
                <td>{$row['unitprice']}</td>
                <td>{$row['totalprice']}</td>
                <td>{$row['quality']}</td>
                <td>{$row['company']}</td>
                <td>{$row['product_date']}</td>
                <td>{$row['expire_date']}</td>
                <td>{$row['guaranty']}</td>
                <td><img src='{$row['image']}' alt='Image' class='view-details' data-id='{$row['product_id']}' style='width: 100px; cursor: pointer;'></td>
              </tr>";
    }
    echo "</tbody>";
} else {
    echo "<tr><td colspan='11' class='text-center'>No records found</td></tr>";
}

$conn->close();
?>
