let slideIndex = 0;
showSlides(slideIndex);

function showSlides(n) {
  let i;
  let slides = document.getElementsByClassName("mySlides");
  let dots = document.getElementsByClassName("dot");

  // Loop through all slides and hide them
  for (i = 0; i < slides.length; i++) {
    slides[i].style.opacity = "0";
  }

  // Loop through all dots and remove "active" class
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" active", "");
  }

  // Reset slideIndex if it exceeds the number of slides
  if (n >= slides.length) {
    slideIndex = 0;
  }

  // Reset slideIndex if it is less than zero
  if (n < 0) {
    slideIndex = slides.length - 1;
  }

  // Set the current slide to be visible and add the "active" class to the corresponding dot
  slides[slideIndex].style.opacity = "1";
  dots[slideIndex].className += " active";

  // Increment the slideIndex to display the next slide in the next iteration
  slideIndex++;

  // Use setTimeout to automatically change slides every 4 seconds
  setTimeout(() => showSlides(slideIndex), 4000);
}

// Function to change slides when clicking next/prev buttons
function plusSlides(n) {
  showSlides((slideIndex += n));
}

// Function to change slides when clicking dot indicators
function currentSlide(n) {
  showSlides((slideIndex = n - 1));
}
