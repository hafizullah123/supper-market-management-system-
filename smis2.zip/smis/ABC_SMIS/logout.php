<?php
session_start();

// Clear the session variables
session_unset();

// Destroy the session
session_destroy();

// Clear the session cookie (if applicable)
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000, 
              $params["path"], 
              $params["domain"], 
              $params["secure"], 
              $params["httponly"]
    );
}

// Output JavaScript to break out of iframe and redirect
echo "<script>
    if (window.top !== window.self) {
        window.top.location.href = 'index.html';
    } else {
        window.location.href = 'index.html';
    }
</script>";
exit();
?>
