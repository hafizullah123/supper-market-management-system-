<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Supplier</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .form-container {
            margin: 50px auto;
            padding: 30px;
            background-color: #ffffff;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            max-width: 600px;
        }
        .form-container h2 {
            text-align: center;
            margin-bottom: 20px;
            color: block;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="form-container">
            <h2>Add Supplier</h2>

            <?php
            // Database connection
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "smis"; // Replace with your database name

            $conn = new mysqli($servername, $username, $password, $dbname);

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // Handle form submission
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                $name = $_POST['name'];
                $phone = $_POST['phone'];
                $email = $_POST['email'];
                $supplier_type = $_POST['supplier_type'];

                // Check if phone already exists
                $stmt = $conn->prepare("SELECT COUNT(*) FROM suplier WHERE phone = ?");
                $stmt->bind_param("i", $phone);
                $stmt->execute();
                $stmt->bind_result($count);
                $stmt->fetch();
                $stmt->close();

                if ($count > 0) {
                    echo '<div class="alert alert-danger" role="alert">Error: Phone number already exists.</div>';
                } else {
                    // Prepare and bind
                    $stmt = $conn->prepare("INSERT INTO suplier (name, phone, email, supplier_type) VALUES (?, ?, ?, ?)");
                    $stmt->bind_param("siss", $name, $phone, $email, $supplier_type);

                    // Execute the statement
                    if ($stmt->execute()) {
                        echo '<div class="alert alert-success" role="alert">New supplier added successfully.</div>';
                    } else {
                        echo '<div class="alert alert-danger" role="alert">Error: ' . $stmt->error . '</div>';
                    }

                    // Close statement
                    $stmt->close();
                }
            }

            // Handle delete request
            if (isset($_GET['delete'])) {
                $delete_id = intval($_GET['delete']);

                // Prepare and execute the SQL statement
                $stmt = $conn->prepare("DELETE FROM suplier WHERE supplier_id = ?");
                $stmt->bind_param("i", $delete_id);

                if ($stmt->execute()) {
                    echo '<div class="alert alert-success" role="alert">Supplier deleted successfully.</div>';
                } else {
                    echo '<div class="alert alert-danger" role="alert">Error: ' . $stmt->error . '</div>';
                }

                // Close statement
                $stmt->close();
            }

            // Close connection
            $conn->close();
            ?>

            <form method="POST" action="">
                 <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" class="form-control" id="name" name="name" required>
                </div> 
                <div class="form-group">
                    <label for="phone">Phone</label>
                    <input type="number" class="form-control" id="phone" name="phone" required>
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" class="form-control" id="email" name="email" required>
                </div>
                <div class="form-group">
                    <label for="supplier_type">Supplier Type</label>
                    <input type="text" class="form-control" id="supplier_type" name="supplier_type" required>
                </div>
                <button type="submit" style="display: block; width: 100px; margin: 0 auto; text-align: center; color: #000; background-color: #f0f0f0; border: none; padding: 10px; border-radius: 5px;">Add Supplier</button>
            </form>
        </div>

        <h2 class="text-center mt-5">Supplier Records</h2>
        <form action="" method="get" class="form-inline mb-4">
            <input type="text" class="form-control mr-sm-2" name="search" placeholder="Search by Name" value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
            <button  type="submit" class="btn ">Search</button>
        </form>

        <table class="table table-bordered">
            <thead>
                <tr>
                    <!-- <th>Supplier ID</th> -->
                    <th>Name</th>
                    <th>Phone</th>
                    <th>Email</th>
                    <th>Supplier Type</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Reconnect to database
                $conn = new mysqli($servername, $username, $password, $dbname);

                // Check connection
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                // Handle search query
                $search = isset($_GET['search']) ? '%' . $conn->real_escape_string($_GET['search']) . '%' : '%';

                // Prepare and execute the SQL statement
                $stmt = $conn->prepare("SELECT * FROM suplier WHERE name LIKE ? ORDER BY supplier_id DESC");
                $stmt->bind_param("s", $search);
                $stmt->execute();
                $result = $stmt->get_result();

                if ($result->num_rows > 0) {
                    // Output data of each row
                    while($row = $result->fetch_assoc()) {
                        echo "<tr>
                               
                                <td>{$row['name']}</td>
                                <td>{$row['phone']}</td>
                                <td>{$row['email']}</td>
                                <td>{$row['supplier_type']}</td>
                                <td><a href='?delete={$row['supplier_id']}' class='btn btn-danger btn-sm' onclick='return confirm(\"Are you sure you want to delete this supplier?\")'>Delete</a></td>
                              </tr>";
                    }
                } else {
                    echo "<tr><td colspan='6' class='text-center'>No suppliers found</td></tr>";
                }

                // Close statement and connection
                $stmt->close();
                $conn->close();
                ?>
            </tbody>
        </table>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.0.11/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
