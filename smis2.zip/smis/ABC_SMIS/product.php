<?php
// Product insertion and management logic

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "smis";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle product insertion
if (isset($_POST['insert'])) {
    $category = $_POST['category'];
    $product_name = $_POST['product_name'];
    $quantity = $_POST['quantity'];
    $unitprice = $_POST['unitprice'];
    $totalprice = $_POST['totalprice'];
    $quality = $_POST['quality'];
    $company = $_POST['company'];
    $product_date = $_POST['product_date'];
    $expire_date = $_POST['expire_date'];
    $guaranty = $_POST['guaranty'];

    $image = $_FILES['image']['name'];
    $target = "images/" . basename($image);

    // Move uploaded file to the target directory
    if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
        $sql = "INSERT INTO product (category, product_name, quantity, unitprice, totalprice, quality, company, product_date, expire_date, guaranty, image)
                VALUES ('$category', '$product_name', '$quantity', '$unitprice', '$totalprice', '$quality', '$company', '$product_date', '$expire_date', '$guaranty', '$target')";

        if ($conn->query($sql) === TRUE) {
            echo "<script>alert('Product added successfully!'); window.location.href='product.php';</script>";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    } else {
        echo "Failed to upload image.";
    }
}

// Handle product deletion
if (isset($_POST['delete'])) {
    $delete_id = $_POST['delete_id'];
    $sql = "DELETE FROM product WHERE product_id = '$delete_id'";
    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Product deleted successfully!'); window.location.href='product.php';</script>";
    } else {
        echo "Error deleting record: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Management</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        .form-container {
            border: 1px solid #dcdcdc;
            border-radius: 8px;
            padding: 20px;
            max-width: 800px;
            margin: auto;
            background-color: #f9f9f9;
            margin-bottom: 30px;
        }
        .form-container label {
            font-weight: bold;
        }
        .form-container input, .form-container select {
            border: 1px solid #ced4da;
            border-radius: 4px;
            padding: 10px;
            width: 100%;
            margin-bottom: 15px;
        }
        .form-container input:focus, .form-container select:focus {
            border-color: #80bdff;
            box-shadow: 0 0 0 0.2rem rgba(38, 143, 255, 0.25);
        }
        .btn-submit {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 4px;
            cursor: pointer;
        }
        .btn-submit:hover {
            background-color: #0056b3;
        }
        .table-container {
            margin-top: 20px;
        }
        .text-center {
            margin-bottom: 20px;
        }
        .product-img {
            cursor: pointer;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <!-- Product Insertion Form -->
        <div class="form-container">
            <h2 class="text-center">Add New Product  </h2>
            <form action="product.php" method="post" enctype="multipart/form-data">
                <label for="category">Category:</label>
                <input type="text" id="category" name="category" required>

                <label for="product_name">Product Name:</label>
                <input type="text" id="product_name" name="product_name" required>

                <label for="quantity">Quantity:</label>
                <input type="text" id="quantity" name="quantity" required>

                <label for="unitprice">Unit Price:</label>
                <input type="text" step="0.01" id="unitprice" name="unitprice" required>

                <label for="totalprice">Total Price:</label>
                <input type="text" step="0.01" id="totalprice" name="totalprice" required>

                <label for="quality">Quality:</label>
                <input type="text" id="quality" name="quality" required>

                <label for="company">Company:</label>
                <input type="text" id="company" name="company" required>

                <label for="product_date">Product Date:</label>
                <input type="date" id="product_date" name="product_date" required>

                <label for="expire_date">Expire Date:</label>
                <input type="date" id="expire_date" name="expire_date" required>

                <label for="guaranty">Guaranty:</label>
                <input type="text" id="guaranty" name="guaranty">

                <label for="image">Product Image:</label>
                <input type="file" id="image" name="image" accept="image/*" required>

                <button type="submit" name="insert" class="btn-submit">Insert Product</button>
            </form>
        </div>

        <!-- Product Display, Update, Delete Form -->
        <div class="form-container">
            <h2 class="text-center">Manage Products</h2>
            <form method="get" class="form-group">
                <input type="text" id="search" class="form-control" name="search" placeholder="Search by product name">
            </form>

            <?php
            // Display products
            $search = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';
            $sql = "SELECT * FROM product WHERE product_name LIKE '%$search%'";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                echo '<div class="table-container">';
                echo '<table class="table table-striped">';
                echo '<thead><tr><th>Product ID</th><th>Image</th><th>Product Name</th><th>Price</th><th>Actions</th></tr></thead>';
                echo '<tbody>';
                while ($row = $result->fetch_assoc()) {
                    echo '<tr>';
                    echo '<td>' . $row['product_id'] . '</td>';
                    echo '<td><img src="' . $row['image'] . '" class="img-fluid product-img" alt="Product Image" data-toggle="modal" data-target="#viewModal' . $row['product_id'] . '" style="max-width: 100px;"></td>';
                    echo '<td>' . $row['product_name'] . '</td>';
                    echo '<td>' . $row['unitprice'] . '</td>';
                    echo '<td>';
                    echo '<form method="post" class="d-inline">';
                    echo '<input type="hidden" name="delete_id" value="' . $row['product_id'] . '">';
                    echo '<button type="submit" name="delete" class="btn btn-danger btn-sm">Delete</button>';
                    echo '</form>';
                    echo '</td>';
                    echo '</tr>';

                    // Modal for viewing product details
                    echo '<div class="modal fade" id="viewModal' . $row['product_id'] . '" tabindex="-1" role="dialog" aria-labelledby="viewModalLabel' . $row['product_id'] . '" aria-hidden="true">';
                    echo '<div class="modal-dialog" role="document" style="max-width: 600px; margin: 30px auto;">'; // Inline CSS for modal dialog
                    echo '<div class="modal-content" style="border-radius: 8px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);">'; // Inline CSS for modal content
                    echo '<div class="modal-header" style="background-color: #f8f9fa; border-bottom: 1px solid #dee2e6; padding: 15px;">'; // Inline CSS for modal header
                    echo '<h5 class="modal-title" id="viewModalLabel' . $row['product_id'] . '" style="margin: 0; font-size: 18px; color: #333;">Product Details</h5>'; // Inline CSS for modal title
                    echo '<button type="button" class="close" data-dismiss="modal" aria-label="Close" style="background: none; border: none; font-size: 1.5rem; color: #333;">'; // Inline CSS for close button
                    echo '<span aria-hidden="true">&times;</span>';
                    echo '</button>';
                    echo '</div>';
                    echo '<div class="modal-body" style="padding: 20px;">'; // Inline CSS for modal body
                    echo '<p style="margin-bottom: 10px;"><strong>Category:</strong> ' . $row['category'] . '</p>'; // Inline CSS for paragraph
                    echo '<p style="margin-bottom: 10px;"><strong>Product Name:</strong> ' . $row['product_name'] . '</p>';
                    echo '<p style="margin-bottom: 10px;"><strong>Quantity:</strong> ' . $row['quantity'] . '</p>';
                    echo '<p style="margin-bottom: 10px;"><strong>Unit Price:</strong> ' . $row['unitprice'] . '</p>';
                    echo '<p style="margin-bottom: 10px;"><strong>Total Price:</strong> ' . $row['totalprice'] . '</p>';
                    echo '<p style="margin-bottom: 10px;"><strong>Quality:</strong> ' . $row['quality'] . '</p>';
                    echo '<p style="margin-bottom: 10px;"><strong>Company:</strong> ' . $row['company'] . '</p>';
                    echo '<p style="margin-bottom: 10px;"><strong>Product Date:</strong> ' . $row['product_date'] . '</p>';
                    echo '<p style="margin-bottom: 10px;"><strong>Expire Date:</strong> ' . $row['expire_date'] . '</p>';
                    echo '<p style="margin-bottom: 10px;"><strong>Guaranty:</strong> ' . $row['guaranty'] . '</p>';
                    echo '<img src="' . $row['image'] . '" class="img-fluid" alt="Product Image" style="max-width: 100%; height: auto; display: block; margin: 20px 0;">'; // Inline CSS for image
                    echo '</div>';
                    echo '</div>';
                    // echo '<div class="modal-footer" style="background-color: #f8f9fa; border-top: 1px solid #dee2e6; padding: 15px;">'; // Inline CSS for modal footer
// echo '<button type="button" class="btn btn-secondary" data-dismiss="modal" style="background-color: #6c757d; border-color: #6c757d;">Close</button>'; // Inline CSS for close button
                    echo '</div>';
                    echo '</div>';
                    echo '</div>';
                    echo '</div>';
                }
                echo '</tbody>';
                echo '</table>';
                echo '</div>';
            } else {
                echo '<p class="text-center">No records found</p>';
            }

            $conn->close();
            ?>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
