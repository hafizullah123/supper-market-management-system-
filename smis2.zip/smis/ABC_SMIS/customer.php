<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "smis";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // File upload configuration
    $target_dir = "uploads/";
    if (!is_dir($target_dir)) {
        mkdir($target_dir, 0777, true);
    }
    
    $target_file = $target_dir . basename($_FILES["Photo"]["name"]);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
    
    // Check if file is an image
    $check = getimagesize($_FILES["Photo"]["tmp_name"]);
    if ($check === false) {
        echo "File is not an image.";
        $uploadOk = 0;
    }

    // Check file size (limit to 5MB)
    if ($_FILES["Photo"]["size"] > 5000000) {
        echo "Sorry, your file is too large.";
        $uploadOk = 0;
    }

    // Allow certain file formats
    if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif") {
        echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
        $uploadOk = 0;
    }

    // Check if $uploadOk is set to 0 by an error
    if ($uploadOk == 0) {
        echo "Sorry, your file was not uploaded.";
    } else {
        if (move_uploaded_file($_FILES["Photo"]["tmp_name"], $target_file)) {
            echo "The file " . htmlspecialchars(basename($_FILES["Photo"]["name"])) . " has been uploaded.";
        } else {
            echo "Sorry, there was an error uploading your file.";
        }
    }

    // Insert data into the database
    $phone = $conn->real_escape_string($_POST['phone']);
    $email = $conn->real_escape_string($_POST['Email']);
    $address = $conn->real_escape_string($_POST['Address']);
    $gender = $conn->real_escape_string($_POST['gender']);
    $photo = $target_file;

    $sql = "INSERT INTO customer (phone, email, address, gender, photo) 
            VALUES ('$phone', '$email', '$address', '$gender', '$photo')";

    if ($conn->query($sql) === TRUE) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Customer Form</title>
</head>
<body>
<div style="border:1px solid #dcdcdc;text-transform: uppercase;background-color:#dcdcdc;max-width:1300px;height:100px;margin:auto">
    <center>
        <a href="index.php">
            <h3><img src="kk.ico" width="100" height="50" alt="Home Icon"><br>GO to home page</h3>
        </a>
    </center>
</div>

<div class="wrapper">
    <div class="registration_form">
        <!-- Title -->
        <div class="title">Customer Form</div>
        <!-- Form -->
        <form action="customer.php" method="post" enctype="multipart/form-data">
            <div class="form_wrap">
                <div class="input_wrap">
                    <label for="email">Phone<b style="color:red"> *</b></label>
                    <input type="number" id="email" name="phone" placeholder="000-000-000-000" style="background: #dcdcdc; border-radius:10px;width: 100%; padding: 10px;" required>
                </div>

                <div class="input_wrap">
                    <label for="country">Email<b style="color:red"> *</b></label>
                    <input type="text" id="country" name="Email" placeholder="Email" required>
                </div>

                <div class="input_wrap">
                    <label for="country">Address<b style="color:red"> *</b></label>
                    <input type="text" id="country" name="Address" placeholder="Address" required>
                </div>

                <div class="input_wrap">
                    <label>Gender<b style="color:red"> *</b></label>
                    <ul>
                        <li>
                            <label class="radio_wrap">
                                <input type="radio" name="gender" value="male" class="input_radio" checked>
                                <span>Male</span>
                            </label>
                        </li>
                        <li>
                            <label class="radio_wrap">
                                <input type="radio" name="gender" value="female" class="input_radio">
                                <span>Female</span>
                            </label>
                        </li>
                    </ul>
                </div>

                <div class="input_wrap">
                    <label for="email">Photo</label>
                    <input type="file" id="email" name="Photo">
                </div>

                <div class="input_wrap">
                    <input type="submit" value="SUBMIT" class="submit_btn">
                </div>
            </div>
        </form>
    </div>
</div>

</body>
</html>
