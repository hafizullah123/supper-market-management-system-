<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "smis";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$query = isset($_GET['query']) ? $conn->real_escape_string($_GET['query']) : '';
$sql = "SELECT * FROM product WHERE product_name LIKE '%$query%' OR category LIKE '%$query%'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo '<table class="table table-bordered">';
    echo '<thead><tr><th>ID</th><th>Category</th><th>Product Name</th><th>Quantity</th><th>Unit Price</th><th>Total Price</th><th>Quality</th><th>Company</th><th>Product Date</th><th>Expire Date</th><th>Guaranty</th><th>Image</th><th>Actions</th></tr></thead>';
    echo '<tbody>';
    while ($row = $result->fetch_assoc()) {
        echo '<tr>';
        echo '<td>' . $row['product_id'] . '</td>';
        echo '<td>' . $row['category'] . '</td>';
        echo '<td>' . $row['product_name'] . '</td>';
        echo '<td>' . $row['quantity'] . '</td>';
        echo '<td>' . $row['unitprice'] . '</td>';
        echo '<td>' . $row['totalprice'] . '</td>';
        echo '<td>' . $row['quality'] . '</td>';
        echo '<td>' . $row['company'] . '</td>';
        echo '<td>' . $row['product_date'] . '</td>';
        echo '<td>' . $row['expire_date'] . '</td>';
        echo '<td>' . $row['guaranty'] . '</td>';
        echo '<td><img src="' . $row['image'] . '" width="100"></td>';
        echo '<td>';
        echo '<button class="btn btn-primary btn-action" onclick="updateProduct(' . $row['product_id'] . ')">Update</button>';
        echo '<button class="btn btn-danger btn-action" onclick="deleteProduct(' . $row['product_id'] . ')">Delete</button>';
        echo '</td>';
        echo '</tr>';
    }
    echo '</tbody>';
    echo '</table>';
} else {
    echo '<p>No products found.</p>';
}

$conn->close();
?>
