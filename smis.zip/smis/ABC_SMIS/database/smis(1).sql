-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 13, 2024 at 07:46 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `smis`
--

-- --------------------------------------------------------

--
-- Table structure for table `about`
--

CREATE TABLE `about` (
  `about_id` int(11) NOT NULL,
  `title` varchar(64) NOT NULL,
  `photo` varchar(128) DEFAULT NULL,
  `comments` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `advertisment`
--

CREATE TABLE `advertisment` (
  `ads_id` int(11) NOT NULL,
  `advertisment_title` varchar(128) NOT NULL,
  `ads_date` date NOT NULL,
  `ads_expire` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `buy`
--

CREATE TABLE `buy` (
  `buy_id` int(11) NOT NULL,
  `product_name` varchar(32) NOT NULL,
  `quanity` varchar(25) DEFAULT NULL,
  `unitprice` varchar(25) DEFAULT NULL,
  `totalprice` varchar(25) DEFAULT NULL,
  `quality` varchar(32) NOT NULL,
  `company` varchar(32) NOT NULL,
  `category` varchar(32) NOT NULL,
  `buy_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `buy`
--

INSERT INTO `buy` (`buy_id`, `product_name`, `quanity`, `unitprice`, `totalprice`, `quality`, `company`, `category`, `buy_date`) VALUES
(1, 'juse', '2', '4', '4', 'good', 'fghsdf', 'drink', '2024-08-08'),
(3, 'bean', '11', '8', '13', '100', 'momand', 'eat', '2024-08-07'),
(4, 'dfgdfg', '223', '232af', '12323$', 'high', 'xdfg', 'drink', '2024-08-12');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `contact_id` int(11) NOT NULL,
  `full_name` varchar(64) NOT NULL,
  `phone` varchar(16) NOT NULL,
  `email` varchar(128) DEFAULT NULL,
  `comments` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`contact_id`, `full_name`, `phone`, `email`, `comments`) VALUES
(2, 'khan', '0704112411', 'jan123@gmail.com', 'akshfkab  aerg aknasdf a asmdn asdf a asef asdg d'),
(3, 'khan', '0704112411', 'khan@gmail.com', 'my order is not recive ');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `customer_id` int(11) NOT NULL,
  `customer_name` varchar(32) NOT NULL,
  `phone` varchar(16) NOT NULL,
  `email` varchar(128) NOT NULL,
  `address` varchar(128) NOT NULL,
  `gender` varchar(16) NOT NULL,
  `photo` varchar(128) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`customer_id`, `customer_name`, `phone`, `email`, `address`, `gender`, `photo`) VALUES
(1, '', '34535345', 'sss@gmail.com', 'sdfg', 'male', 'uploads/Screenshot 2024-08-03 025044.png'),
(2, '', '07024112411', 'khan@gmail.com', 'kabul', 'male', 'uploads/Screenshot 2024-08-03 025044.png');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `employee_id` int(11) NOT NULL,
  `firtsname` varchar(32) NOT NULL,
  `lastname` varchar(32) NOT NULL,
  `fname` varchar(32) NOT NULL,
  `identity_no` int(11) NOT NULL,
  `phone` varchar(16) NOT NULL,
  `email` varchar(128) NOT NULL,
  `address` varchar(128) NOT NULL,
  `dob` int(11) NOT NULL,
  `gender` varchar(16) NOT NULL,
  `photo` varchar(128) NOT NULL,
  `education` varchar(32) NOT NULL,
  `salary` int(11) NOT NULL,
  `shiptime` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`employee_id`, `firtsname`, `lastname`, `fname`, `identity_no`, `phone`, `email`, `address`, `dob`, `gender`, `photo`, `education`, `salary`, `shiptime`) VALUES
(1, 'sdgdfg', 'gsdfgsdg', 'gsdfgsdfg', 5, '345123452345', 'sss@gmail.com', 'sdfgsdgsdfg', 2024, 'male', '', 'sdfgsdfg', 2323, '04:04'),
(4, 'dfgdfg', 'dddd', 'gggg', 454, '5433', 'ssdd@gmail.com', 'hhgfds', 2024, 'female', '', 'sdffgg', 6543, '08:23'),
(5, 'hafiz', 'jihad', 'ali', 123, '0704112411', 'hjihadwal@gmail.com', 'kabul', 1381, 'man', 'sdf', 'bcs', 100, '2am');

-- --------------------------------------------------------

--
-- Table structure for table `expense`
--

CREATE TABLE `expense` (
  `expense_id` int(11) NOT NULL,
  `title` varchar(64) NOT NULL,
  `receiver` varchar(64) NOT NULL,
  `amount` varchar(25) DEFAULT NULL,
  `currency` varchar(25) DEFAULT NULL,
  `expense_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `expense`
--

INSERT INTO `expense` (`expense_id`, `title`, `receiver`, `amount`, `currency`, `expense_date`) VALUES
(9, 'eating', 'khan', '234af', '$', '2024-08-15'),
(10, 'هندسه', 'khalid', '234af', 'af', '2024-08-06'),
(11, 'شرح ده احادیثو', 'khan', '234af', 'af', '2024-08-14');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `product_name` varchar(32) NOT NULL,
  `order_date` date DEFAULT NULL,
  `quanity` int(11) NOT NULL,
  `subscriber_name` varchar(32) NOT NULL,
  `phone` varchar(16) NOT NULL,
  `email` varchar(128) DEFAULT NULL,
  `gender` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `product_name`, `order_date`, `quanity`, `subscriber_name`, `phone`, `email`, `gender`) VALUES
(1, 'juse', '2024-08-27', 2, 'ali', '34234234', 'manager1@gmail.com', 1),
(2, 'geril', '2024-08-19', 3, 'basit', '0704112411', 'this@gmail.com', 1),
(3, ' apple juse', '2024-08-11', 6, 'khan', '0704112411', 'hafizullah@gmail.com', 1);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `product_id` int(11) NOT NULL,
  `category` varchar(32) NOT NULL,
  `product_name` varchar(32) NOT NULL,
  `quantity` int(11) NOT NULL,
  `unitprice` varchar(25) DEFAULT NULL,
  `totalprice` varchar(25) DEFAULT NULL,
  `quality` varchar(32) DEFAULT NULL,
  `company` varchar(32) NOT NULL,
  `product_date` date DEFAULT NULL,
  `expire_date` date DEFAULT NULL,
  `guaranty` varchar(25) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`product_id`, `category`, `product_name`, `quantity`, `unitprice`, `totalprice`, `quality`, `company`, `product_date`, `expire_date`, `guaranty`, `image`) VALUES
(10, 'drink', 'juse', 7, '8', '21', '12', 'srhdfh', '2024-08-06', '2025-09-29', '1', ''),
(13, 'dg', 'dfggsdg', 4, '8', '18', 'good', 'fghsdf', '0000-00-00', '0000-00-00', '1', 'uploads/h1.jpg'),
(14, 'drink', 'geril', 2, '3', '2', 'good', 'xdfg', '2022-03-03', '2024-08-14', '1', 'uploads/h2.jpg'),
(15, 'eat', 'bean', 50, '100', '5000', 'high', 'momand', '2024-08-08', '2024-08-23', '100', 'uploads/s22.jpg'),
(16, 'eat', 'bean', 11, '232af', '12323$', 'good', 'momand', '2024-08-14', '2024-08-22', '100%', 'uploads/3h.jpg'),
(19, 'eat', 'bean', 11, '232af', '12323$', 'good', 'momand', '2024-08-14', '2024-08-22', '100%', 'uploads/3h.jpg'),
(23, 'sgf', 'gasdg', 3, '232af', '12323$', 'good', 'srhdfh', '2024-08-23', '2024-08-31', '100%', 'uploads/Screenshot 2024-03-10 064939.png'),
(24, 'eat', 'dfggsdg', 3, '231.96', '12323', 'good', 'momand', '2024-08-08', '2024-08-22', '100%', 'images/Screenshot 2024-03-10 065131.png'),
(25, 'drink', 'gasdg', 232, '232af', '12323$', 'good', 'srhdfh', '2024-09-01', '2024-08-30', '100%', 'images/Screenshot 2024-03-10 070246.png'),
(26, 'sgf', 'juse', 232, '232af', '12323$', 'good', 'xdfg', '2024-08-08', '2024-08-20', '100%', 'images/Screenshot 2024-03-10 070505.png');

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `sales_id` int(11) NOT NULL,
  `sales_date` date DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `unitprice` varchar(25) DEFAULT NULL,
  `totalprice` varchar(25) DEFAULT NULL,
  `quality` varchar(32) NOT NULL,
  `discount` varchar(25) DEFAULT NULL,
  `customer_name` varchar(32) NOT NULL,
  `category` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`sales_id`, `sales_date`, `quantity`, `unitprice`, `totalprice`, `quality`, `discount`, `customer_name`, `category`) VALUES
(1, '2024-08-16', 4, '8', '8', 'good', '12', 'sedt', 'dg'),
(2, '2024-08-09', 8, '7', '6', 'low', '5', 'sedt', 'drink'),
(3, '2024-08-14', 4, '7', '4', 'xcf', '8', 'good', 'drink'),
(4, '2024-08-14', 4, '7', '4', 'xcf', '2', 'good', 'drink'),
(5, '2024-08-14', 4, '7', '4', 'xcf', '2', 'lsd', 'drink'),
(6, '2024-08-14', 4, '7', '4', 'xcf', '2', 'lsd', 'drink'),
(7, '2024-08-07', 1, '12', '12', 'good', '1', 'sadid', 'eat'),
(8, '2024-08-01', 232, '232', '12323', '100%', '2af', 'sadid', 'eat'),
(9, '2024-08-07', 23, '232', '12323', '100%', '2af', 'lsd', 'drink');

-- --------------------------------------------------------

--
-- Table structure for table `subscriber`
--

CREATE TABLE `subscriber` (
  `subscriber_id` int(11) NOT NULL,
  `subscriber_name` varchar(32) NOT NULL,
  `phone` varchar(16) NOT NULL,
  `email` varchar(128) NOT NULL,
  `address` varchar(128) NOT NULL,
  `comments` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `suplier`
--

CREATE TABLE `suplier` (
  `supplier_id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `phone` int(16) NOT NULL,
  `email` varchar(30) NOT NULL,
  `supplier_type` varchar(16) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `suplier`
--

INSERT INTO `suplier` (`supplier_id`, `name`, `phone`, `email`, `supplier_type`) VALUES
(2, 'عبدالباسط', 704112411, 'manager123@gmail.com', 'public'),
(5, 'حفیظ الله', 704112414, 'ali@gmail.com', 'public'),
(6, 'balal', 23232323, 'khanm@gmail.com', 'public');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `employee_id` int(11) NOT NULL,
  `username` varchar(32) NOT NULL,
  `password` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users1`
--

CREATE TABLE `users1` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users1`
--

INSERT INTO `users1` (`id`, `name`, `password`) VALUES
(1, 'ali', '12345');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `about`
--
ALTER TABLE `about`
  ADD PRIMARY KEY (`about_id`);

--
-- Indexes for table `advertisment`
--
ALTER TABLE `advertisment`
  ADD PRIMARY KEY (`ads_id`);

--
-- Indexes for table `buy`
--
ALTER TABLE `buy`
  ADD PRIMARY KEY (`buy_id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`contact_id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`employee_id`),
  ADD UNIQUE KEY `identity_no` (`identity_no`),
  ADD UNIQUE KEY `phone` (`phone`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `expense`
--
ALTER TABLE `expense`
  ADD PRIMARY KEY (`expense_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`sales_id`);

--
-- Indexes for table `subscriber`
--
ALTER TABLE `subscriber`
  ADD PRIMARY KEY (`subscriber_id`);

--
-- Indexes for table `suplier`
--
ALTER TABLE `suplier`
  ADD PRIMARY KEY (`supplier_id`),
  ADD UNIQUE KEY `phone` (`phone`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`employee_id`);

--
-- Indexes for table `users1`
--
ALTER TABLE `users1`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `about`
--
ALTER TABLE `about`
  MODIFY `about_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `advertisment`
--
ALTER TABLE `advertisment`
  MODIFY `ads_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `buy`
--
ALTER TABLE `buy`
  MODIFY `buy_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `contact_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `customer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `employee_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `expense`
--
ALTER TABLE `expense`
  MODIFY `expense_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `sales_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `subscriber`
--
ALTER TABLE `subscriber`
  MODIFY `subscriber_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `suplier`
--
ALTER TABLE `suplier`
  MODIFY `supplier_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `employee_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users1`
--
ALTER TABLE `users1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `employee_user_fk` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`employee_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
