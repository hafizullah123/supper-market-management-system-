<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contacts List</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .table-container {
            margin: 50px auto;
            padding: 30px;
            background-color: #ffffff;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }
        .table-container h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #007bff;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="table-container">
            <h2>Contacts List <a href="home.php">Home</h2>

            <?php
            // Database connection
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "smis"; // Replace with your database name

            $conn = new mysqli($servername, $username, $password, $dbname);

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // Handle delete request
            if (isset($_POST['delete'])) {
                $contact_id = $_POST['contact_id'];
                $delete_sql = "DELETE FROM contact WHERE contact_id = ?";
                $stmt = $conn->prepare($delete_sql);
                $stmt->bind_param("i", $contact_id);
                if ($stmt->execute()) {
                    echo '<div class="alert alert-success" role="alert">Contact deleted successfully.</div>';
                } else {
                    echo '<div class="alert alert-danger" role="alert">Error deleting contact.</div>';
                }
                $stmt->close();
            }

            // Fetch data from the contact table
            $sql = "SELECT contact_id, full_name, phone, email, comments FROM contact ORDER BY contact_id DESC";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                echo '<table class="table table-bordered table-striped">';
                echo '<thead class="thead-dark">';
                echo '<tr>';
                echo '<th>Contact ID</th>';
                echo '<th>Full Name</th>';
                echo '<th>Phone</th>';
                echo '<th>Email</th>';
                echo '<th>Actions</th>';
                echo '</tr>';
                echo '</thead>';
                echo '<tbody>';

                // Output data of each row
                while($row = $result->fetch_assoc()) {
                    echo '<tr>';
                    echo '<td>' . $row["contact_id"] . '</td>';
                    echo '<td>' . $row["full_name"] . '</td>';
                    echo '<td>' . $row["phone"] . '</td>';
                    echo '<td>' . $row["email"] . '</td>';
                    echo '<td>
                        <button type="button" class="btn btn-primary view-details" data-toggle="modal" data-target="#contactModal" data-id="' . $row["contact_id"] . '" data-name="' . $row["full_name"] . '" data-phone="' . $row["phone"] . '" data-email="' . $row["email"] . '" data-comments="' . htmlspecialchars($row["comments"]) . '">View Details</button>
                        <form method="POST" action="" class="d-inline">
                            <input type="hidden" name="contact_id" value="' . $row["contact_id"] . '">
                            <button type="submit" name="delete" class="btn btn-danger" onclick="return confirm(\'Are you sure you want to delete this contact?\')">Delete</button>
                        </form>
                    </td>';
                    echo '</tr>';
                }
                echo '</tbody>';
                echo '</table>';
            } else {
                echo '<div class="alert alert-info" role="alert">No contacts found.</div>';
            }

            $conn->close();
            ?>

            <!-- Modal -->
            <div class="modal fade" id="contactModal" tabindex="-1" aria-labelledby="contactModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="contactModalLabel">Contact Details</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <p><strong>Full Name:</strong> <span id="modal-fullname"></span></p>
                            <p><strong>Phone:</strong> <span id="modal-phone"></span></p>
                            <p><strong>Email:</strong> <span id="modal-email"></span></p>
                            <p><strong>Comments:</strong></p>
                            <p id="modal-comments"></p>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.0.11/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        $(document).ready(function() {
            $('.view-details').on('click', function() {
                var name = $(this).data('name');
                var phone = $(this).data('phone');
                var email = $(this).data('email');
                var comments = $(this).data('comments');

                $('#modal-fullname').text(name);
                $('#modal-phone').text(phone);
                $('#modal-email').text(email);
                $('#modal-comments').text(comments);
            });
        });
    </script>
</body>
</html>
