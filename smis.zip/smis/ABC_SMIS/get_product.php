<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "smis";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST['id'])) {
    $product_id = $conn->real_escape_string($_POST['id']);

    $sql = "SELECT * FROM product WHERE product_id = $product_id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        echo "<h4>Product Details</h4>";
        echo "<p><strong>ID:</strong> " . $row['product_id'] . "</p>";
        echo "<p><strong>Category:</strong> " . $row['category'] . "</p>";
        echo "<p><strong>Product Name:</strong> " . $row['product_name'] . "</p>";
        echo "<p><strong>Quantity:</strong> " . $row['quantity'] . "</p>";
        echo "<p><strong>Unit Price:</strong> " . $row['unitprice'] . "</p>";
        echo "<p><strong>Total Price:</strong> " . $row['totalprice'] . "</p>";
        echo "<p><strong>Quality:</strong> " . $row['quality'] . "</p>";
        echo "<p><strong>Company:</strong> " . $row['company'] . "</p>";
        echo "<p><strong>Product Date:</strong> " . $row['product_date'] . "</p>";
        echo "<p><strong>Expire Date:</strong> " . $row['expire_date'] . "</p>";
        echo "<p><strong>Guaranty:</strong> " . $row['guaranty'] . "</p>";
        if ($row['image']) {
            echo "<p><strong>Image:</strong><br><img src='" . $row['image'] . "' alt='Product Image' style='width: 100%; height: auto;'></p>";
        } else {
            echo "<p><strong>Image:</strong> No Image</p>";
        }
    } else {
        echo "Product not found.";
    }

    $conn->close();
}
