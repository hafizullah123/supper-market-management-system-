<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Page Title</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
        }

        /* Header Styling */
        #header {
            border: 1px solid #dcdcdc;
            background-color: #dcdddc;
            width: 100%;
            height: 70px;
            text-align: center;
            padding: 20px 0;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
        }

        #header h1 {
            font-size: 2.5em;
            font-weight: bold;
            margin: 0;
            color: black;
        }

        #header h1 a {
            text-decoration: none;
            color: black;
            background-color: #dcdddc;
        }

        #header h1 a:hover {
            color: red;
            text-shadow: 3px 4px 6px #00ffff;
        }

        /* Main Content Styling */
        .container {
            display: flex;
            margin-top: 70px; /* Ensure content is below the fixed header */
        }

        #sidebar {
            border: 1px solid #dfdfdf;
            background-color: #dfdfdf;
            width: 220px;
            padding: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            flex-shrink: 0;
        }

        #sidebar h1 {
            color: black;
            font-size: 1.5em;
            margin-top: 0;
        }

        #sidebar ol {
            list-style-type: square;
            padding-left: 20px;
            margin: 0;
        }

        #sidebar ol a {
            text-decoration: none;
            font-weight: bold;
            color: black;
            display: block;
            padding: 5px 0;
        }

        #sidebar ol a:hover {
            text-shadow: 4px 4px 5px red;
            font-size: 1.1em;
        }

        .image-container {
            border: 1px solid #dcdcdc;
            background-color: #9fffd0;
            flex: 1;
            margin: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            max-width: 800px; /* Set a max-width for the image */
            height: auto;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .image-container img {
            max-width: 100%;
            height: auto;
        }

        /* Footer Styling */
        #footer {
            width: 100%;
            height: 80px;
            background-color: #dcdcdc;
            border-top: 1px solid #dcdcdc;
            text-align: center;
            line-height: 80px;
            font-size: 1.2em;
            color: black;
            margin-top: 20px;
            box-shadow: 0 -4px 8px rgba(0, 0, 0, 0.1);
        }

        #footer b {
            display: block;
            color: red;
        }

        #footer .email {
            color: green;
        }
    </style>
</head>
<body>
    <div id="header">
        <h1><a href="#">Heda <span style="color:red">yatullah</span> Nezami</a></h1>
    </div>

    <div class="container">
        <div id="sidebar">
            <h1>Forms</h1>
            <ol>
                <li><a href="supplier.php">Supplier</a></li>
                <li><a href="buy.php">Buy</a></li>
                <li><a href="employee.php">Employee Form</a></li>
                <li><a href="product.php">Product</a></li>
                <li><a href="sales.php">Sales</a></li>
                <!-- <li><a href="customer.php">Customer</a></li> -->
                <!-- <li><a href="subscriber.php">Subscriber</a></li> -->
                <li><a href="expense.php">Expense</a></li>
                <li><a href="select_order.php">Orders</a></li>
                <!-- <li><a href="users.php">Users</a></li> -->
                <li><a href="select_contact.php">Contact</a></li>
                <!-- <li><a href="about.php">About</a></li> -->
                <li><a href="logout.php">Logout</a></li>
            </ol>
        </div>

        <div class="image-container">
            <img src="ss.jpg" alt="Image">
        </div>
    </div>

    <div id="footer">
        <b>07777777</b>
        <b>Gmail:</b> <span class="email">hedaytullah.nezami@gmail.com</span>
    </div>
</body>
</html>
