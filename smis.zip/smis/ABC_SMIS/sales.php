<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "smis";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission for inserting data
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['insert'])) {
    $sales_date = $_POST['sales_date'];
    $quantity = $_POST['quantity'];
    $unitprice = $_POST['unitprice'];
    $totalprice = $_POST['totalprice'];
    $quality = $_POST['quality'];
    $discount = $_POST['discount'];
    $customer_name = $_POST['customer_name'];
    $category = $_POST['category'];

    // Prepare and bind
    $stmt = $conn->prepare("INSERT INTO sales (sales_date, quantity, unitprice, totalprice, quality, discount, customer_name, category) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("siiissss", $sales_date, $quantity, $unitprice, $totalprice, $quality, $discount, $customer_name, $category);

    // Execute the statement
    if ($stmt->execute()) {
        echo '<div class="alert alert-success" role="alert">New sales record created successfully.</div>';
    } else {
        echo '<div class="alert alert-danger" role="alert">Error: ' . $stmt->error . '</div>';
    }

    // Close statement
    $stmt->close();
}

// Fetch data for display
$sql = "SELECT * FROM sales";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sales Management</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        .container {
            max-width: 900px;
        }
        .form-container, .table-container {
            margin-bottom: 30px;
        }
        .btn-submit {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 4px;
            cursor: pointer;
        }
        .btn-submit:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <!-- Insert Form -->
        <div class="form-container">
            <h2 class="text-center">Insert Sales Record  <a href="home.php">Home</a></h2>
            <form method="POST" action="">
                <div class="form-group">
                    <label for="sales_date">Sales Date</label>
                    <input type="date" class="form-control" id="sales_date" name="sales_date" required>
                </div>
                <div class="form-group">
                    <label for="quantity">Quantity</label>
                    <input type="number" class="form-control" id="quantity" name="quantity" required>
                </div>
                <div class="form-group">
                    <label for="unitprice">Unit Price</label>
                    <input type="text" step="0.01" class="form-control" id="unitprice" name="unitprice" required>
                </div>
                <div class="form-group">
                    <label for="totalprice">Total Price</label>
                    <input type="text" step="0.01" class="form-control" id="totalprice" name="totalprice" required>
                </div>
                <div class="form-group">
                    <label for="quality">Quality</label>
                    <input type="text" class="form-control" id="quality" name="quality" required>
                </div>
                <div class="form-group">
                    <label for="discount">Discount</label>
                    <input type="text"  class="form-control" id="discount" name="discount" required>
                </div>
                <div class="form-group">
                    <label for="customer_name">Customer Name</label>
                    <input type="text" class="form-control" id="customer_name" name="customer_name" required>
                </div>
                <div class="form-group">
                    <label for="category">Category</label>
                    <input type="text" class="form-control" id="category" name="category" required>
                </div>
                <button type="submit" name="insert" class="btn-submit">Insert Record</button>
            </form>
        </div>

        <!-- Data Table -->
        <div class="table-container">
            <h2 class="text-center">Sales Records</h2>
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>Sales ID</th>
                        <th>Sales Date</th>
                        <th>Quantity</th>
                        <th>Unit Price</th>
                        <th>Total Price</th>
                        <th>Quality</th>
                        <th>Discount</th>
                        <th>Customer Name</th>
                        <th>Category</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($result->num_rows > 0): ?>
                        <?php while($row = $result->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo $row["sales_id"]; ?></td>
                                <td><?php echo $row["sales_date"]; ?></td>
                                <td><?php echo $row["quantity"]; ?></td>
                                <td><?php echo $row["unitprice"]; ?></td>
                                <td><?php echo $row["totalprice"]; ?></td>
                                <td><?php echo $row["quality"]; ?></td>
                                <td><?php echo $row["discount"]; ?></td>
                                <td><?php echo $row["customer_name"]; ?></td>
                                <td><?php echo $row["category"]; ?></td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="9" class="text-center">No records found</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>

<?php
// Close connection
$conn->close();
?>
