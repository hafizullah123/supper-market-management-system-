<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Search</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        .search-container {
            margin: 20px auto;
            max-width: 800px;
        }
        .table-container {
            margin: 20px auto;
            max-width: 800px;
        }
        .table-container img {
            cursor: pointer;
        }
        .modal-content img {
            max-width: 100%;
        }
        @media (max-width: 768px) {
            .table-responsive th, .table-responsive td {
                white-space: nowrap;
            }
            .table-container img {
                width: 80px;
            }
        }
    </style>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        $(document).ready(function(){
            $('#search').on('keyup', function() {
                var query = $(this).val();
                $.ajax({
                    url: 'search.php',
                    method: 'POST',
                    data: { query: query },
                    success: function(data) {
                        $('#product-table').html(data);
                    }
                });
            });

            // Event delegation for dynamically loaded content
            $(document).on('click', '.view-details', function() {
                var id = $(this).data('id');
                $.ajax({
                    url: 'get_product.php',
                    method: 'POST',
                    data: { id: id },
                    success: function(data) {
                        $('#modal-body').html(data);
                        $('#productModal').modal('show');
                    }
                });
            });
        });
    </script>
</head>
<body>
    <div class="container">
        <div class="search-container">
            <h1 class="text-center">Search Products</h1>
            <input type="text" id="search" class="form-control" placeholder="Search by category or product name">
        </div>

        <div class="table-container">
            <div class="table-responsive">
                <table class="table table-bordered" id="product-table">
                    <!-- Table content will be loaded here by AJAX -->
                </table>
            </div>
        </div>
    </div>

    <!-- Product Details Modal -->
    <div class="modal fade" id="productModal" tabindex="-1" role="dialog" aria-labelledby="productModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="productModalLabel">Product Details</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body" id="modal-body">
                    <!-- Product details will be loaded here by AJAX -->
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
