<html>
<head>

<link rel="stylesheet" href="style.css">
</head>
<body>

<div style="border:1px solid #dcdcdc;text-transform: uppercase;background-color:#dcdcdc;max-width:1300px;height:100px;margin:auto">
<center><P> <a href="index.php"><font style="size:80px"><h3>   <img src="kk.ico"width="100"height="50"> <br>GO to home page</img>  </a></h3> </center></font>
	</div>

<div class="wrapper"> 


<div class="registration_form">
<!-- Title -->  <div class="title">    Advertisment FORM </div><!-- Form -->

 
 <form>  
	<div class="form_wrap">   
	
  <div class="input_wrap"> 
	<table width="100%" style="padding:10px;" cel>
		<tr>
			<td>Advertisment Title</td>
			<td><input type="text" id="Title" class="input" name="ATitle"  placeholder="Title"></td>
			</tr>
		<tr>
			<td>Advertisment Date</td>
			<td><input type="Date" id="phone" class="input" onkeypress='OnlyNumber(event)' name="Advertisment Date" > </td>
			</tr>
			
		<tr>
			<td>  Advertisment Expire</td>
			<td><input type="Date" id="  Advertisment Expire" class="input" onkeypress='OnlyNumber(event)' name="  Advertisment Expire"> </td>
			</tr>
		
		<tr>
			<td colspan="4" style="text-align:right;">	<input type="submit" onclick="return Validate();" value="SUBMIT" class="submit_btn"></td>
		</tr>
	</table>  
	
	<div id="error" style="color:red;">
	</div>

</form>
 
 
 
 
 </div></div>
 </body>

 </html>