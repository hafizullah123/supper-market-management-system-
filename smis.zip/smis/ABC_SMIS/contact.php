<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Form</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .form-container {
            max-width: 600px;
            margin: 50px auto;
            padding: 30px;
            background-color: #ffffff;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }
        .form-container h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #007bff;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="form-container">
            <h2>Contact Us  <a href="home.php">Home</a></h2>

            <?php
            // Database connection
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "smis"; // Replace with your database name

            $conn = new mysqli($servername, $username, $password, $dbname);

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // Handling form submission
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                $full_name = $_POST['full_name'];
                $phone = $_POST['phone'];
                $email = $_POST['email'];
                $comments = $_POST['comments'];

                // Prepare and bind
                $stmt = $conn->prepare("INSERT INTO contact (full_name, phone, email, comments) VALUES (?, ?, ?, ?)");
                $stmt->bind_param("ssss", $full_name, $phone, $email, $comments);

                // Execute the statement
                if ($stmt->execute()) {
                    echo '<div class="alert alert-success" role="alert">Thank you for contacting us!</div>';
                } else {
                    echo '<div class="alert alert-danger" role="alert">Error: ' . $stmt->error . '</div>';
                }

                // Close connections
                $stmt->close();
            }

            $conn->close();
            ?>

            <form action="" method="POST">
                <div class="form-group">
                    <label for="full_name">Full Name</label>
                    <input type="text" class="form-control" id="full_name" name="full_name" required>
                </div>
                <div class="form-group">
                    <label for="phone">Phone</label>
                    <input type="text" class="form-control" id="phone" name="phone" required>
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" class="form-control" id="email" name="email">
                </div>
                <div class="form-group">
                    <label for="comments">Comments</label>
                    <textarea class="form-control" id="comments" name="comments" rows="4"></textarea>
                </div>
                <button type="submit" class="btn btn-primary btn-block">Submit</button>
            </form>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.0.11/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
