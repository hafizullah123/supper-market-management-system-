<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Form</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .form-container {
            max-width: 600px;
            margin: 50px auto;
            padding: 30px;
            background-color: #ffffff;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }
        .form-container h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #007bff;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="form-container">
            <h2>Place an Order</h2>

            <?php
            // Database connection
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "smis"; // Replace with your database name

            $conn = new mysqli($servername, $username, $password, $dbname);

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // Handling form submission
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                $product_name = $_POST['product_name'];
                $order_date = $_POST['order_date'];
                $quanity = $_POST['quanity'];
                $subscriber_name = $_POST['subscriber_name'];
                $phone = $_POST['phone'];
                $email = $_POST['email'];
                $gender = $_POST['gender'];

                // Prepare and bind
                $stmt = $conn->prepare("INSERT INTO orders (product_name, order_date, quanity, subscriber_name, phone, email, gender) VALUES (?, ?, ?, ?, ?, ?, ?)");
                $stmt->bind_param("ssisssi", $product_name, $order_date, $quanity, $subscriber_name, $phone, $email, $gender);

                // Execute the statement
                if ($stmt->execute()) {
                    echo '<div class="alert alert-success" role="alert">New order placed successfully</div>';
                } else {
                    echo '<div class="alert alert-danger" role="alert">Error: ' . $stmt->error . '</div>';
                }

                // Close connections
                $stmt->close();
            }

            $conn->close();
            ?>

            <form action="" method="POST">
                <div class="form-group">
                    <label for="product_name">Product Name</label>
                    <input type="text" class="form-control" id="product_name" name="product_name" required>
                </div>
                <div class="form-group">
                    <label for="order_date">Order Date</label>
                    <input type="date" class="form-control" id="order_date" name="order_date">
                </div>
                <div class="form-group">
                    <label for="quanity">Quantity</label>
                    <input type="number" class="form-control" id="quanity" name="quanity" required>
                </div>
                <div class="form-group">
                    <label for="subscriber_name">Subscriber Name</label>
                    <input type="text" class="form-control" id="subscriber_name" name="subscriber_name" required>
                </div>
                <div class="form-group">
                    <label for="phone">Phone</label>
                    <input type="text" class="form-control" id="phone" name="phone" required>
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" class="form-control" id="email" name="email">
                </div>
                <div class="form-group">
                    <label for="gender">Gender</label>
                    <select class="form-control" id="gender" name="gender" required>
                        <option value="1">Male</option>
                        <option value="0">Female</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary btn-block">Submit</button>
            </form>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.0.11/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
