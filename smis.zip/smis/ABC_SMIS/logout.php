<?php
// Clear the session identifier cookie
setcookie('session_id', '', time() - 3600, "/");

// Redirect to the login page
header("Location: index.html");
exit();
?>
