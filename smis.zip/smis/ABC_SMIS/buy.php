<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "smis";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Insert data
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $product_name = $_POST['product_name'];
    $quanity = $_POST['quanity'];
    $unitprice = $_POST['unitprice'];
    $totalprice = $_POST['totalprice'];
    $quality = $_POST['quality'];
    $company = $_POST['company'];
    $category = $_POST['category'];
    $buy_date = $_POST['buy_date'];

    $sql = "INSERT INTO buy (product_name, quanity, unitprice, totalprice, quality, company, category, buy_date) 
            VALUES ('$product_name', '$quanity', '$unitprice', '$totalprice', '$quality', '$company', '$category', '$buy_date')";

    if ($conn->query($sql) === TRUE) {
        echo "<div class='alert success'>New record created successfully</div>";
    } else {
        echo "<div class='alert error'>Error: " . $sql . "<br>" . $conn->error . "</div>";
    }
}

// Search and display data
$search = "";
if (isset($_GET['search'])) {
    $search = $_GET['search'];
}

$sql = "SELECT * FROM buy WHERE product_name LIKE '%$search%' OR category LIKE '%$search%' OR company LIKE '%$search%'";
$result = $conn->query($sql);

// Delete record
if (isset($_GET['delete'])) {
    $buy_id = $_GET['delete'];
    $delete_sql = "DELETE FROM buy WHERE buy_id = $buy_id";
    if ($conn->query($delete_sql) === TRUE) {
        echo "<div class='alert success'>Record deleted successfully</div>";
    } else {
        echo "<div class='alert error'>Error deleting record: " . $conn->error . "</div>";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Buy Records <a href="home.php">Home</a></title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
        }
        h2 {
            color: #343a40;
            margin-bottom: 20px;
        }
        .form-container {
            background-color: #fff;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            width: 100%;
            max-width: 500px;
        }
        .form-container input[type="text"], .form-container input[type="number"], .form-container input[type="date"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ced4da;
            border-radius: 5px;
            font-size: 16px;
        }
        .form-container button[type="submit"] {
            background-color: #007bff;
            color: #fff;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            width: 100%;
            font-size: 16px;
            font-weight: 500;
        }
        .form-container button[type="submit"]:hover {
            background-color: #0056b3;
        }
        .search-box {
            width: 100%;
            max-width: 500px;
            margin-bottom: 20px;
        }
        .search-box input[type="text"] {
            width: calc(100% - 100px);
            padding: 10px;
            border: 1px solid #ced4da;
            border-radius: 5px;
            font-size: 16px;
        }
        .search-box button[type="submit"] {
            background-color: #007bff;
            color: #fff;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            font-weight: 500;
        }
        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 5px;
            color: white;
            text-align: center;
        }
        .alert.success {
            background-color: #28a745;
        }
        .alert.error {
            background-color: #dc3545;
        }
        table {
            width: 100%;
            max-width: 900px;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            overflow: hidden;
        }
        table, th, td {
            border: 1px solid #dee2e6;
        }
        th, td {
            padding: 15px;
            text-align: left;
            font-size: 16px;
        }
        th {
            background-color: #007bff;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        td a {
            color: #dc3545;
            text-decoration: none;
            font-weight: 500;
        }
        td a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <h2>Insert Buy Record</h2>
    <div class="form-container">
        <form action="buy.php" method="post">
            Product Name: <input type="text" name="product_name" required><br>
            Quantity: <input type="text" name="quanity" required><br>
            Unit Price: <input type="text" name="unitprice" required><br>
            Total Price: <input type="text" name="totalprice" required><br>
            Quality: <input type="text" name="quality" required><br>
            Company: <input type="text" name="company" required><br>
            Category: <input type="text" name="category" required><br>
            Buy Date: <input type="date" name="buy_date" required><br>
            <button type="submit">Submit</button>
        </form>
    </div>

    <h2>Search Buy Records</h2>
    <div class="search-box">
        <form method="get" action="buy.php">
            <input type="text" name="search" value="<?php echo $search; ?>" placeholder="Search...">
            <button type="submit">Search</button>
        </form>
    </div>

    <h2>Buy Records</h2>
    <table>
        <thead>
            <tr>
                <!-- <th>Buy ID</th> -->
                <th>Product Name</th>
                <th>Quantity</th>
                <th>Unit Price</th>
                <th>Total Price</th>
                <th>Quality</th>
                <th>Company</th>
                <th>Category</th>
                <th>Buy Date</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    // echo "<td>" . $row['buy_id'] . "</td>";
                    echo "<td>" . $row['product_name'] . "</td>";
                    echo "<td>" . $row['quanity'] . "</td>";
                    echo "<td>" . $row['unitprice'] . "</td>";
                    echo "<td>" . $row['totalprice'] . "</td>";
                    echo "<td>" . $row['quality'] . "</td>";
                    echo "<td>" . $row['company'] . "</td>";
                    echo "<td>" . $row['category'] . "</td>";
                    echo "<td>" . $row['buy_date'] . "</td>";
                    echo "<td><a href='buy.php?delete=" . $row['buy_id'] . "' onclick='return confirm(\"Are you sure?\")'>Delete</a></td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='10'>No records found</td></tr>";
            }
            ?>
        </tbody>
    </table>
</body>
</html>
