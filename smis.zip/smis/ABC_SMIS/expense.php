<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Expense Management</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
        }
        .container {
            margin-top: 20px;
        }
        .table {
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2 class="text-center">Insert Expense <a href="home.php">Home</a></h2>
        <form action="" method="post">
            <div class="form-group">
                <label for="title">Title:</label>
                <input type="text" class="form-control" id="title" name="title" required>
            </div>
            <div class="form-group">
                <label for="receiver">Receiver:</label>
                <input type="text" class="form-control" id="receiver" name="receiver" required>
            </div>
            <div class="form-group">
                <label for="amount">Amount:</label>
                <input type="text" class="form-control" id="amount" name="amount" required>
            </div>
            <div class="form-group">
                <label for="currency">Currency:</label>
                <input type="text" class="form-control" id="currency" name="currency" required>
            </div>
            <div class="form-group">
                <label for="expense_date">Expense Date:</label>
                <input type="date" class="form-control" id="expense_date" name="expense_date">
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>

        <?php
        // Check if the form is submitted
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            // Get data from form
            $title = $_POST['title'];
            $receiver = $_POST['receiver'];
            $amount = $_POST['amount'];
            $currency = $_POST['currency'];
            $expense_date = $_POST['expense_date'];

            // Database connection
            $conn = new mysqli('localhost', 'root', '', 'smis');

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // Prepare and execute the SQL statement
            $stmt = $conn->prepare("INSERT INTO expense (title, receiver, amount, currency, expense_date) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param("sssss", $title, $receiver, $amount, $currency, $expense_date);

            if ($stmt->execute()) {
                // Redirect after successful insertion to prevent form resubmission
                header("Location: " . $_SERVER['PHP_SELF']);
                exit;
            } else {
                echo "<div class='alert alert-danger text-center'>Error: " . $stmt->error . "</div>";
            }

            // Close statement and connection
            $stmt->close();
            $conn->close();
        }

        // Handle delete request
        if (isset($_GET['delete'])) {
            $delete_id = intval($_GET['delete']);

            // Database connection
            $conn = new mysqli('localhost', 'root', '', 'smis');

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // Prepare and execute the SQL statement
            $stmt = $conn->prepare("DELETE FROM expense WHERE expense_id = ?");
            $stmt->bind_param("i", $delete_id);

            if ($stmt->execute()) {
                // Redirect after successful deletion to prevent resubmission
                header("Location: " . $_SERVER['PHP_SELF']);
                exit;
            } else {
                echo "<div class='alert alert-danger text-center'>Error: " . $stmt->error . "</div>";
            }

            // Close statement and connection
            $stmt->close();
            $conn->close();
        }
        ?>

        <h2 class="text-center mt-5">Expense Records</h2>
        <form action="" method="get" class="form-inline mb-4">
            <input type="text" class="form-control mr-sm-2" name="search" placeholder="Search by Title" value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
            <button type="submit" class="btn btn-primary">Search</button>
        </form>

        <table class="table table-bordered">
            <thead>
                <tr>
                    <!-- Hiding the Expense ID column -->
                    <!--<th>Expense ID</th>-->
                    <th>Title</th>
                    <th>Receiver</th>
                    <th>Amount</th>
                    <th>Currency</th>
                    <th>Expense Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Database connection
                $conn = new mysqli('localhost', 'root', '', 'smis');

                // Check connection
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                // Handle search query
                $search = isset($_GET['search']) ? '%' . $conn->real_escape_string($_GET['search']) . '%' : '%';

                // Prepare and execute the SQL statement
                $stmt = $conn->prepare("SELECT * FROM expense WHERE title LIKE ? ORDER BY expense_id DESC");
                $stmt->bind_param("s", $search);
                $stmt->execute();
                $result = $stmt->get_result();

                if ($result->num_rows > 0) {
                    // Output data of each row
                    while($row = $result->fetch_assoc()) {
                        echo "<tr>
                                <!--<td>{$row['expense_id']}</td>-->
                                <td>{$row['title']}</td>
                                <td>{$row['receiver']}</td>
                                <td>{$row['amount']}</td>
                                <td>{$row['currency']}</td>
                                <td>{$row['expense_date']}</td>
                                <td><a href='?delete={$row['expense_id']}' class='btn btn-danger btn-sm' onclick='return confirm(\"Are you sure you want to delete this record?\")'>Delete</a></td>
                              </tr>";
                    }
                } else {
                    echo "<tr><td colspan='6' class='text-center'>No records found</td></tr>";
                }

                // Close statement and connection
                $stmt->close();
                $conn->close();
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>
