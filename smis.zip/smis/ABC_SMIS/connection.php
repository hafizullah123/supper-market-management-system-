<?php
$con = mysql_connect("localhost","root","");
mysql_select_db("smis");

/*
mysql_connect ("server , user , password");
mysql_select_db("dbname");
$recordset = mysql_query (sql query);
mysql_fetch_assoc ($recordset);
mysql_num_rows();
*/
?>