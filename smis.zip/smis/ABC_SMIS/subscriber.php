<html>
<head>

<link rel="stylesheet" href="style.css">
</head>
<body>



<div style="border:1px solid #dcdcdc;text-transform: uppercase;background-color:#dcdcdc;max-width:1300px;height:100px;margin:auto">
<center><P> <a href="index.php"><font style="size:80px"><h3>   <img src="kk.ico"width="100"height="50"> <br>GO to home page</img>  </a></h3> </center></font>
	</div>

<div class="wrapper"> 


<div class="registration_form">
<!-- Title -->  <div class="title"> Subscriber Form </div><!-- Form -->
 
 
  <form>  <div class="form_wrap">   <div class="input_grp"><!-- Frist name input Place --> 
 
   </div><!-- Email Id input Place -->
   
<div class="input_wrap">  <label for="email">Phone<b style="color:red"> *</b></label>  <input type="number" id="email"name="phone" placeholder="000-000-000-000"style="background: #dcdcdc; border-radius:10px;width: 100%;  padding: 10px;"required> </div><!-- City Name input place -->
<div class="input_wrap">  <label for="country"> Email<b style="color:red"> *</b></label>  <input type="text" id="country"name="Email" placeholder="Email"required> </div>
<div class="input_wrap">  <label for="country"> Address<b style="color:red"> *</b></label>  <input type="text" id="country"name="Address" placeholder="Address"required> </div>
<div class="input_wrap">  <label for="country"> Comments</label>  <textarea cols="10" rows="9" placeholder="write here your comment"style="background: #dcdcdc; border-radius:10px;width: 100%;  padding: 10px;"></textarea> </div>

 <div class="input_wrap"> 
 <input type="submit" value="SUBMIT" class="submit_btn">
 </div></div></form></div></div>    
 </body>
 
  <script>
function OnlyNumber(evt) {
  var theEvent = evt || window.event;

  // Handle paste
  if (theEvent.type === 'paste') {
      key = event.clipboardData.getData('text/plain');
  } else {
  // Handle key press
      var key = theEvent.keyCode || theEvent.which;
      key = String.fromCharCode(key);
  }
  var regex = /[0-9]|\./;
  if( !regex.test(key) ) {
    theEvent.returnValue = false;
    if(theEvent.preventDefault) theEvent.preventDefault();
  }
}
	
</script>
 </html>