<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "smis";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $input_username = $_POST['username'];
    $input_password = $_POST['password'];

    // Query to check if the user exists
    $sql = "SELECT id FROM users1 WHERE name = ? AND password = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $input_username, $input_password);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        // User found, start session
        $_SESSION['username'] = $input_username;
        header("Location: home.php"); // Redirect to dashboard or home page
        exit();
    } else {
        // User not found
        echo "<script>alert('Invalid username or password');</script>";
    }
    $stmt->close();
}

$conn->close();
?>
